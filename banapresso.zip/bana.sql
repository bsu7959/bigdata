use jspstudy;

create table bana (
	bana_idx bigint auto_increment primary key,
    bana_name varchar(20) not null,
    bana_address varchar(50) not null
);
drop table bana;
select * from bana;