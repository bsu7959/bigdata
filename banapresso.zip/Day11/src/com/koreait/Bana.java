package com.koreait;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Bana {

	public static void main(String[] args) {
		String DRIVER_ID = "webdriver.chrome.driver";
		String DRIVER_PATH = "C:/sangu/jars/chromedriver_win32/chromedriver.exe";
		
		System.setProperty(DRIVER_ID, DRIVER_PATH);
		WebDriver driver = new ChromeDriver();
		
		String base_url = "https://www.banapresso.com/store";
		
		List<String> list = new ArrayList<>();
		List<String> list2 = new ArrayList<>();
		HashMap<String, String> map = new HashMap<>();
		Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
		try {
			driver.get(base_url);


			System.out.println("**************** 베스트 댓글 *******************");

			 int i = 2;

			 while(true) {
				List<WebElement> element = driver.findElements(By.cssSelector("span.store_name_map > i"));
				List<WebElement> element2 = driver.findElements(By.cssSelector("span.store_name_map > i + span"));
				 try {	

						for(WebElement el : element) {
							list.add(el.getText());
						}

						for(WebElement el2 : element2) {
							list2.add(el2.getText().trim());
						}
					 
							 if(i<=5) {
								 WebElement Nextpage = driver.findElement(
										 	By.cssSelector("div.store_list_box > div.pagination > ul > li:nth-child("+i+")")
										 );
										 Nextpage.click();
										 Thread.sleep(2000);
								 i++;
							 }else {
								 WebElement Nexttab = driver.findElement(
										 	By.cssSelector("div.store_list_box > div.pagination > span.btn_page_next > a")
										 );
								 Nexttab.click();
								 Thread.sleep(2000);
								 i=2;
							 }
							 
				 }catch(Exception e) {
					 System.out.println("프로그램종료");
					 break;
				 }
			 }
			 int a = 1;
			 for(String str : list2) {
				 System.out.println(a);
				 a++;
				 System.out.println(str);
			 }
	         driver.close();
	         String sql = "";
	         String url = "jdbc:mysql://localhost:3306/jspstudy";
	         String uid = "root";
	         String upw = "1234";
	            
	         Class.forName("com.mysql.jdbc.Driver");
	         conn = DriverManager.getConnection(url, uid, upw);
	         if(conn != null){
	        	 int j = 0;
	        	 if(list.size() > list2.size()) {
	        		 for(j=0; j<list2.size(); j++) {
	        			 sql = "insert into bana(bana_name, bana_address) values (?,?)";
	        			 pstmt = conn.prepareStatement(sql);
	        			 pstmt.setString(1, list.get(j));
	        			 pstmt.setString(2, list2.get(j));
	        			 pstmt.executeUpdate();
	        		 }
	        		 for(int k=0; k<list.size(); k++) {
	        			 sql = "insert into bana(bana_name) values (?)";
	        			 pstmt = conn.prepareStatement(sql);
	        			 pstmt.setString(1, list.get(k));
	        			 pstmt.executeUpdate();
	        		 }
	        	 }else {
	        		 for(j=0; j<list.size(); j++) {
	        			 sql = "insert into bana(bana_name, bana_address) values (?,?)";
	        			 pstmt = conn.prepareStatement(sql);
	        			 pstmt.setString(1, list.get(j));
	        			 pstmt.setString(2, list2.get(j));
	        			 pstmt.executeUpdate();
	        		 }
	        	 }
	         }

		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
