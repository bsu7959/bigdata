package com.koreait;

import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/*
 * 네이버 영화 평점 크롤링 (https://movie.naver.com/)
 * 접속 주소 : https://movie.naver.com/movie/point/af/list.nhn
 */
public class Main3 {

	public static void main(String[] args) throws InterruptedException {
		String url = "https://movie.naver.com/movie/point/af/list.nhn?page=";
		Document doc = null;
		for(int i=1; i<=10; i++) {		
		try {
			doc = Jsoup.connect(url+i).get();
			Thread.sleep(2000);
			System.out.println("*******************" + i + "페이지 *************************");
			Elements elements = doc.select("table.list_netizen");
			Iterator<Element> titles = elements.select("a.color_b").iterator();
			Iterator<Element> scores = elements.select("div.list_netizen_score").iterator();
			Iterator<Element> reviews = elements.select("td.title").iterator();
			
			Pattern pat;	// 문자열의 패턴을 만듭니다
			Matcher mat;	// 일치하는 문자열을 검사합니다
			
			
			while(titles.hasNext()) {
				String title = titles.next().text();
				String score = scores.next().text().replace("별점 - 총 10점 중", "");
				score = "총 10점 중 " + score + "점";
				String review = reviews.next().text().replace(title, "");
				review = review.substring(0, review.length()-3);
				pat = Pattern.compile(" 별점 - 총 10점 중[0-9]{1,2}");
				mat = pat.matcher(review);
				review = mat.replaceAll("").trim();
				System.out.println("영화제목 : " + title);
				System.out.println("평점 : " + score);
				System.out.println("리뷰 : " + review);
				System.out.println("***********************************************");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		}
	}
}
