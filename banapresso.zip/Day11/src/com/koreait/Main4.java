package com.koreait;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main4 {

	public static void main(String[] args) {
		String DRIVER_ID = "webdriver.chrome.driver";
		String DRIVER_PATH = "C:/sangu/jars/chromedriver_win32/chromedriver.exe";
		
		System.setProperty(DRIVER_ID, DRIVER_PATH);
		WebDriver driver = new ChromeDriver();
		
		String base_url = "https://google.com";
		
		try {
			driver.get(base_url);
			System.out.println(driver.getPageSource());
			WebElement webElement = driver.findElement(By.name("q"));
			webElement.sendKeys("날씨");
			webElement.submit();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
