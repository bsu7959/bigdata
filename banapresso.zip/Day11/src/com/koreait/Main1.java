package com.koreait;

import java.util.Iterator;
import org.jsoup.nodes.Element;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import org.jsoup.select.Elements;

/*
 * cgv ( https://www.cgv.co.kr/)
 * 무비 차트 크롤링 
 * 접속 주소 : http://www.cgv.co.kr/movies/
 */
public class Main1 {

	public static void main(String[] args) {
		String url = "http://www.cgv.co.kr/movies/";
		System.out.println("접속 주소 : " + url);
		
		Document doc = null;
		try {
			doc = Jsoup.connect(url).get();
			System.out.println("접속 성공");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		Elements elements = doc.select("div.sect-movie-chart");
		Iterator<Element> rank = elements.select("strong.rank").iterator();
		Iterator<Element> title = elements.select("strong.title").iterator();
		
		while(rank.hasNext()) {
			System.out.println(rank.next().text() + " : " + title.next().text());
		}
	}

}
