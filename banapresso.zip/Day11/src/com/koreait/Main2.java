package com.koreait;

import java.util.Iterator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/*
 * 벅스뮤직 벅스차트 크롤링 ( http://music.bugs.co.kr/)
 * 접속 주소 : https://music.bugs.co.kr/chart
 * */
public class Main2 {

	public static void main(String[] args) {
		String url = "https://music.bugs.co.kr/chart";
		Document doc = null;
		
		try {
			doc = Jsoup.connect(url).get();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		Elements elements = doc.select("table.byChart");
		Iterator<Element> title = elements.select("p.title").iterator();
		Iterator<Element> artist = elements.select("p.artist").iterator();
		
		int rank = 1;
		
		while(title.hasNext()) {
			System.out.println(rank + "위 " + artist.next().text() + " - " + title.next().text());
			rank++;
		}
	}

}
