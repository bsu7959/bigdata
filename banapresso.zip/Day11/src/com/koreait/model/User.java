package com.koreait.model;

public class User {
	private int userNum;
	private String userName;
	private int userAge;
	private String userHp;
	private String userAddr;
	
	public User(int userNum, String userName, int userAge, String userHp, String userAddr) {
		this.userNum = userNum;
		this.userName = userName;
		this.userAge = userAge;
		this.userHp = userHp;
		this.userAddr = userAddr;
	}

	public int getUserNum() {
		return userNum;
	}

	public void setUserNum(int userNum) {
		this.userNum = userNum;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getUserAge() {
		return userAge;
	}

	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}

	public String getUserHp() {
		return userHp;
	}

	public void setUserHp(String userHp) {
		this.userHp = userHp;
	}

	public String getUserAddr() {
		return userAddr;
	}

	public void setUserAddr(String userAddr) {
		this.userAddr = userAddr;
	}

	@Override
	public String toString() {
		return "User [userNum=" + userNum + ", userName=" + userName + ", userAge=" + userAge + ", userHp=" + userHp
				+ ", userAddr=" + userAddr + "]";
	}
	
}
