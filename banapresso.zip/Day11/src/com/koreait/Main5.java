package com.koreait;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main5 {
	public static void main(String[] args) {
		String DRIVER_ID = "webdriver.chrome.driver";
		String DRIVER_PATH = "C:/sangu/jars/chromedriver_win32/chromedriver.exe";
		
		System.setProperty(DRIVER_ID, DRIVER_PATH);
		WebDriver driver = new ChromeDriver();
		
		String base_url = "https://www.agoda.com/ko-kr/five-jumeirah-village/hotel/all/dubai-ae.html?finalPriceView=1&isShowMobileAppPrice=false&cid=1891463&numberOfBedrooms=&familyMode=false&adults=20&children=0&rooms=2&maxRooms=0&checkIn=2021-03-24&isCalendarCallout=false&childAges=&numberOfGuest=0&missingChildAges=false&travellerType=3&showReviewSubmissionEntry=false&currencyCode=KRW&isFreeOccSearch=false&tag=2eeaad89-ed27-f176-7894-75ff35865eaa&tspTypes=5,8&los=30&searchrequestid=7692f529-eeb8-43e5-89cd-eb989e488e72\r\n"
				+ "";
		
		try {
			driver.get(base_url);
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
			Thread.sleep(2000);
			// System.out.println(driver.getPageSource());
			List<WebElement> elements = driver.findElements(By.className("Review-comment-bodyText"));
			for(WebElement el : elements) {
				System.out.println(el.getText());
			}

			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
