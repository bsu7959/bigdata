package com.koreait.api;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

import com.koreait.model.User;
/**
 * Servlet implementation class FormTest3
 */
@WebServlet("/FormTest3")
public class FormTest3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FormTest3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<User> list = new ArrayList<>();
		User user1 = new User(1, "김사과1", 21, "010-1111-1111", "서울 1서초구");
		User user2 = new User(2, "김사과2", 22, "010-1111-1112", "서울 2서초구");
		User user3 = new User(3, "김사과3", 23, "010-1111-1113", "서울 3서초구");
		User user4 = new User(4, "김사과4", 24, "010-1111-1114", "서울 4서초구");
		User user5 = new User(5, "김사과5", 25, "010-1111-1115", "서울 5서초구");
		
		list.add(user1);
		list.add(user2);
		list.add(user3);
		list.add(user4);
		list.add(user5);
		
		int userNum = Integer.parseInt(request.getParameter("userNum"));
		User user = list.get(userNum);
		
		JSONObject result = new JSONObject();
		result.put("userNo", user.getUserNum());
		result.put("userName", URLEncoder.encode(user.getUserName(), "UTF-8"));
		result.put("userAge", user.getUserAge());
		result.put("userHp", user.getUserHp());
		result.put("userAddr", URLEncoder.encode(user.getUserAddr(), "UTF-8"));
		
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		out.print(result);
		out.flush();
		out.close();
	}

}
