package com.koreait;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main6 {

	public static void main(String[] args) {
		String DRIVER_ID = "webdriver.chrome.driver";
		String DRIVER_PATH = "C:/sangu/jars/chromedriver_win32/chromedriver.exe";
		
		System.setProperty(DRIVER_ID, DRIVER_PATH);
		WebDriver driver = new ChromeDriver();
		
		String base_url = "https://comic.naver.com/comment/comment.nhn?titleId=716857&no=306";
		
		try {
			driver.get(base_url);
			List<WebElement> element = driver.findElements(By.className("u_cbox_contents"));
			System.out.println("**************** 베스트 댓글 *******************");
			for(WebElement el : element) {
				System.out.println(el.getText());
			}
			List<WebElement> Btns = driver.findElements(By.className("u_cbox_sort_label"));
			Btns.get(1).click();
			Thread.sleep(2000);
			System.out.println("**************** 일반 댓글 *******************");
			element = driver.findElements(By.className("u_cbox_contents"));
			for(WebElement el : element) {
				System.out.println(el.getText());
			}
			 int i = 4;
			 while(true) {
				 try {
					 WebElement Nextpage = driver.findElement(
							 	By.cssSelector("div.u_cbox_paginate > div.u_cbox_page_wrap > a:nth-child("+i+") > span")
							 );
							 Nextpage.click();
							 Thread.sleep(2000);
							 element = driver.findElements(By.className("u_cbox_content"));
							 for(WebElement el : element) {
								 System.out.println(el.getText());
							 }
							 if(i<=12) {
								 i++;
							 }else {
								 i=4;
							 }
				 }catch(Exception e) {
					 System.out.println("프로그램종료");
					 break;
				 }
			 }
			System.out.println("끝");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
